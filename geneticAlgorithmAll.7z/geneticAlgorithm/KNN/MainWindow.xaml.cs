﻿using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KNN;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        InitPointData();
        ClearLogger();
    }

    private void ClearLogger()
    {
        Logger.Document.Blocks.Clear();
    }

    private void InitPointData()
    {
        PointData = [];
        foreach (string points in Points.Split(Environment.NewLine))
        {
            string[] coordsAndClass = points.Split(',');

            List<double> tempList = [];
            foreach (string num in coordsAndClass)
            {
                tempList.Add(Convert.ToDouble(num.Trim()));
            }

            PointData.Add(new(tempList));
            tempList.Clear();
        }

        double[] minValues = [Double.PositiveInfinity, Double.PositiveInfinity, Double.PositiveInfinity, Double.PositiveInfinity];
        double[] maxValues = [Double.NegativeInfinity, Double.NegativeInfinity, Double.NegativeInfinity, Double.NegativeInfinity];

        foreach (List<double> row in PointData)
        {
            for (int idx = 0; idx < row.Count - 1; idx++)
            {
                if (row[idx] < minValues[idx])
                {
                    minValues[idx] = row[idx];
                }

                if (row[idx] > maxValues[idx])
                {
                    maxValues[idx] = row[idx];
                }
            }
        }

        MinValues = minValues;
        MaxValues = maxValues;

        double euclid(List<double> coords, List<double> point)
        {
            double sum = 0;
            for (int i = 0; i < coords.Count; i++)
            {
                sum += Math.Pow(point[i] - coords[i], 2);
            }

            return Math.Sqrt(sum);
        }

        double manhattan(List<double> coords, List<double> point)
        {
            double sum = 0;
            for (int i = 0; i < coords.Count; i++)
            {
                sum += Math.Abs(point[i] - coords[i]);
            }
            return sum;
        }

        double chebyshev(List<double> coords, List<double> point)
        {
            double maxDiff = 0;
            for (int i = 0; i < coords.Count; i++)
            {
                double diff = Math.Abs(point[i] - coords[i]);
                if (diff > maxDiff)
                {
                    maxDiff = diff;
                }
            }
            return maxDiff;
        }

        double cosine(List<double> coords, List<double> point)
        {
            double dot = 0;
            double normA = 0;
            double normB = 0;

            for (int i = 0; i < coords.Count; i++)
            {
                dot += coords[i] * point[i];
                normA += coords[i] * coords[i];
                normB += point[i] * point[i];
            }

            if (normA <= 0 || normB <= 0)
            {
                return 1.0;
            }

            return 1.0 - dot / (Math.Sqrt(normA) * Math.Sqrt(normB));
        }

        double minkowski(List<double> coords, List<double> point)
        {
            double sum = 0;
            for (int i = 0; i < coords.Count; i++)
            {
                sum += Math.Pow(Math.Abs(point[i] - coords[i]), P);
            }
            return Math.Pow(sum, 1.0 / P);
        }

        DelegateWrapper[] metrics = [new DelegateWrapper(euclid,    "Euklides"),
                                     new DelegateWrapper(chebyshev, "Chebyshev"),
                                     new DelegateWrapper(manhattan, "Manhattan"),
                                     new DelegateWrapper(cosine,    "Cosinus"),
                                     new DelegateWrapper(minkowski, "Minkowski")];

        MetricBox.ItemsSource = metrics;
        MetricBox.DisplayMemberPath = "ComboBoxLabel";
        MetricBox.SelectedIndex = 0;

        foreach (List<double> row in PointData)
        {
            for (int idx = 0; idx < row.Count - 1; idx++)
            {
                row[idx] = (row[idx] - minValues[idx]) / (maxValues[idx] - minValues[idx]);
            }
        }
    }

    private void Log(string msg)
    {
        var line = new Paragraph(new Run($"{msg}"))
        {
            Margin = new Thickness(0)
        };
        Logger.Document.Blocks.Add(line);
        Logger.ScrollToEnd();
    }

    private double KNN(List<double> coords, int k, int testedIdx = -1)
    {
        List<Tuple<double, double>> distancesAndClasses = [];
        if (MetricBox.SelectedItem is DelegateWrapper selectedMetric)
        {
            var metric = selectedMetric.Metric;

            int idx = 0;
            foreach (List<double> point in PointData)
            {
                if (idx++ != testedIdx)
                {
                    distancesAndClasses.Add(Tuple.Create(metric(coords, [point[0], point[1], point[2], point[3]]), point[4]));
                }
            }
        }

        List<Tuple<double, double>> kNearest = [];

        for (int i = 0; i < k; i++)
        {
            int minIdx = 0;

            for (int j = 0; j < distancesAndClasses.Count; j++)
            {
                if (distancesAndClasses[j].Item1 < distancesAndClasses[minIdx].Item1)
                {
                    minIdx = j;
                }
            }

            kNearest.Add(new Tuple<double, double>(distancesAndClasses[minIdx].Item1, distancesAndClasses[minIdx].Item2));
            distancesAndClasses.RemoveAt(minIdx);
        }

        Dictionary<double, int> classCounts = [];

        foreach (Tuple<double, double> distanceAndClass in kNearest)
        {
            if (classCounts.ContainsKey(distanceAndClass.Item2))
            {
                classCounts[distanceAndClass.Item2]++;
            }
            else
            {
                classCounts[distanceAndClass.Item2] = 1;
            }
        }

        int maxVotes = -1;
        double chosenClass = -1;

        foreach (var kvp in classCounts)
        {
            if (kvp.Value > maxVotes ||
                (kvp.Value == maxVotes && kvp.Key < chosenClass))
            {
                maxVotes = kvp.Value;
                chosenClass = kvp.Key;
            }
        }

        return chosenClass;
    }

    private void OnClassifyClick(object sender, RoutedEventArgs e)
    {
        if (AutoClear)
        {
            ClearLogger();
        }

        DelegateWrapper delegateWrapper = (DelegateWrapper)MetricBox.SelectedItem;
        string[] coords = CoordInput.Text.Split(',');
        string kparam = KInput.Text;

        if (coords.Length != 4)
        {
            MessageBox.Show("Wprowadź dokładnie 4 współrzędne oddzielone przecinkami.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }

        if (!int.TryParse(kparam, out int k) || k <= 0)
        {
            MessageBox.Show("Wprowadź poprawny parametr K (liczba całkowita większa od 0).", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }

        if (delegateWrapper.ComboBoxLabel == "Minkowski")
        {
            if (!int.TryParse(PInput.Text, out P) || P <= 0)
            {
                MessageBox.Show("Wprowadź poprawny parametr P (liczba całkowita większa od 0).", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
        }

        List<double> coordsList = [];
        foreach (string str in coords)
        {
            try
            {
                coordsList.Add(Convert.ToDouble(str.Trim()));
            }
            catch (FormatException)
            {
                MessageBox.Show("Wprowadź poprawne współrzędne (liczby zmiennoprzecinkowe).", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
        }

        for (int i = 0; i < coordsList.Count; i++)
        {
            coordsList[i] = (coordsList[i] - MinValues[i]) / (MaxValues[i] - MinValues[i]);
        }

        Log($"Wybrana metryka: {delegateWrapper.ComboBoxLabel}");
        Log("Przewidziana klasa: " + Convert.ToInt64(KNN(coordsList, k)).ToString());
    }

    private void OnTestClick(object sender, RoutedEventArgs e)
    {
        if (AutoClear)
        {
            ClearLogger();
        }

        string kparam = KInput.Text.Trim();
        if (!int.TryParse(kparam, out int k) || k <= 0)
        {
            MessageBox.Show("Wprowadź poprawny parametr K (liczba całkowita większa od 0).", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }

        DelegateWrapper delegateWrapper = (DelegateWrapper)MetricBox.SelectedItem;
        if (delegateWrapper.ComboBoxLabel == "Minkowski")
        {
            if (!int.TryParse(PInput.Text, out P) || P <= 0)
            {
                MessageBox.Show("Wprowadź poprawny parametr P (liczba całkowita większa od 0).", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
        }

        StringBuilder sb = new StringBuilder();
        int correctCount = 0;
        int idx = 0;
        foreach (List<double> row in PointData)
        {
            List<double> coords = [row[0], row[1], row[2], row[3]];
            double actualClass = row[4];
            double predictedClass = KNN(coords, k, idx);
            sb.AppendLine($"Rzeczywista klasa: {actualClass} | Przewidziana klasa: {predictedClass}");
            if (actualClass == predictedClass)
            {
                correctCount++;
            }
            ++idx;
        }
        sb.AppendLine($"Liczba poprawnych klasyfikacji: {correctCount}/{PointData.Count} ({(double)correctCount / PointData.Count * 100.0}%)");
        Log(sb.ToString());
    }

    private void MetricBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (MetricBox.SelectedItem is DelegateWrapper selectedMetric)
        {
            if (AutoClear)
            {
                ClearLogger();
            }

            Log($"Wybrana metryka: {selectedMetric.ComboBoxLabel}");

            if (selectedMetric.ComboBoxLabel == "Minkowski")
            {
                PInput.Visibility = Visibility.Visible;
            }
            else
            {
                PInput.Visibility = Visibility.Collapsed;
            }
        }
    }

    private void OnClearClick(object sender, RoutedEventArgs e)
    {
        ClearLogger();
    }

    private void CoordInput_GotFocus(object sender, RoutedEventArgs e)
    {
        if (sender is TextBox textBox)
        {
            if (textBox.Text == "4 współrzędne po przecinku")
            {
                textBox.Text = string.Empty;
                textBox.Foreground = Brushes.Black;
            }
        }
    }

    private void CoordInput_LostFocus(object sender, RoutedEventArgs e)
    {
        if (sender is TextBox textBox)
        {
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = "4 współrzędne po przecinku";
                textBox.Foreground = Brushes.Gray;
            }
        }
    }

    private void KInput_GotFocus(object sender, RoutedEventArgs e)
    {
        if (sender is TextBox textBox)
        {
            if (textBox.Text == "Parametr K")
            {
                textBox.Text = string.Empty;
                textBox.Foreground = Brushes.Black;
            }
        }
    }

    private void KInput_LostFocus(object sender, RoutedEventArgs e)
    {
        if (sender is TextBox textBox)
        {
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = "Parametr K";
                textBox.Foreground = Brushes.Gray;
            }
        }
    }

    private void PInput_GotFocus(object sender, RoutedEventArgs e)
    {
        if (sender is TextBox textBox)
        {
            if (textBox.Text == "Minkowski parametr P")
            {
                textBox.Text = string.Empty;
                textBox.Foreground = Brushes.Black;
            }
        }
    }

    private void PInput_LostFocus(object sender, RoutedEventArgs e)
    {
        if (sender is TextBox textBox)
        {
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = "Minkowski parametr P";
                textBox.Foreground = Brushes.Gray;
            }
        }
    }

    private void CheckBox_Checked(object sender, RoutedEventArgs e)
    {
        AutoClear = true;
        ClearLogger();
        Log("Automatyczne czyszczenie logu włączone");
    }

    private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
    {
        AutoClear = false;
        Log("Automatyczne czyszczenie logu wyłączone");
    }

    private bool AutoClear;
    private int P;
    private double[] MinValues;
    private double[] MaxValues;
    private List<List<double>> PointData; // X,Y,Z,W,KLASA

    private readonly string Points =
@"6.5,3,5.2,2,3
5.1,2.5,3,1.1,2
4.9,3.1,1.5,0.1,1
4.9,3.1,1.5,0.1,1
6.8,3,5.5,2.1,3
6.9,3.1,4.9,1.5,2
5.1,3.3,1.7,0.5,1
6,2.9,4.5,1.5,2
6.2,2.8,4.8,1.8,3
4.8,3.1,1.6,0.2,1
6.1,2.8,4,1.3,2
6.8,3.2,5.9,2.3,3
5.4,3.4,1.7,0.2,1
5,2.3,3.3,1,2
6.7,2.5,5.8,1.8,3
6.5,2.8,4.6,1.5,2
5,3.4,1.5,0.2,1
6.4,2.7,5.3,1.9,3
5.6,3,4.1,1.3,2
5.8,2.7,5.1,1.9,3
5.4,3.9,1.3,0.4,1
5.5,2.4,3.8,1.1,2
4.7,3.2,1.3,0.2,1
7.7,3.8,6.7,2.2,3
5.6,2.8,4.9,2,3
6.7,3,5,1.7,2
5.1,3.5,1.4,0.2,1
5.9,3,4.2,1.5,2
5,3.2,1.2,0.2,1
6.5,3.2,5.1,2,3
6.1,2.6,5.6,1.4,3
5.7,4.4,1.5,0.4,1
6,2.7,5.1,1.6,2
5.8,4,1.2,0.2,1
6.5,3,5.5,1.8,3
5.8,2.7,3.9,1.2,2
5,3.5,1.6,0.6,1
6,2.2,4,1,2
7.9,3.8,6.4,2,3
4.9,3,1.4,0.2,1
6.7,3.1,4.7,1.5,2
6.7,3.3,5.7,2.5,3
6.1,2.9,4.7,1.4,2
5,3.5,1.3,0.3,1
5.8,2.8,5.1,2.4,3
7.2,3.6,6.1,2.5,3
6.7,3.1,4.4,1.4,2
5.1,3.5,1.4,0.3,1
6.3,3.3,4.7,1.6,2
6.3,3.4,5.6,2.4,3
4.3,3,1.1,0.1,1
4.6,3.1,1.5,0.2,1
6.3,3.3,6,2.5,3
6.4,2.9,4.3,1.3,2
5.1,3.8,1.6,0.2,1
6.5,3,5.8,2.2,3
5.6,2.5,3.9,1.1,2
4.9,3.1,1.5,0.1,1
6.7,3.3,5.7,2.1,3
5,2,3.5,1,2
6.9,3.1,5.1,2.3,3
5.9,3.2,4.8,1.8,2
4.5,2.3,1.3,0.3,1
6.3,2.5,5,1.9,3
5.6,2.7,4.2,1.3,2
5.4,3.9,1.7,0.4,1
6.9,3.1,5.4,2.1,3
4.4,3,1.3,0.2,1
4.9,2.4,3.3,1,2
5,3,1.6,0.2,1
6.4,2.8,5.6,2.2,3
6.3,2.3,4.4,1.3,2
7.3,2.9,6.3,1.8,3
4.6,3.2,1.4,0.2,1
5.8,2.7,4.1,1,2
4.8,3.4,1.9,0.2,1
5.6,2.9,3.6,1.3,2
6.7,3.1,5.6,2.4,3
5.7,2.5,5,2,3
5.8,2.6,4,1.2,2
4.6,3.4,1.4,0.3,1
5.2,2.7,3.9,1.4,2
5.8,2.7,5.1,1.9,3
5,3.6,1.4,0.2,1
5.2,3.5,1.5,0.2,1
6.4,3.2,4.5,1.5,2
7.2,3.2,6,1.8,3
5.6,3,4.5,1.5,2
5.9,3,5.1,1.8,3
5.1,3.7,1.5,0.4,1
6.8,2.8,4.8,1.4,2
4.8,3.4,1.6,0.2,1
7.7,3,6.1,2.3,3
6.6,3,4.4,1.4,2
4.4,2.9,1.4,0.2,1
7.1,3,5.9,2.1,3
6.6,2.9,4.6,1.3,2
7.4,2.8,6.1,1.9,3
5.4,3.7,1.5,0.2,1
6.2,3.4,5.4,2.3,3
5.5,2.3,4,1.3,2
5.2,4.1,1.5,0.1,1
5,3.4,1.6,0.4,1
7,3.2,4.7,1.4,2
7.7,2.8,6.7,2,3
5.7,3,4.2,1.2,2
6.1,3,4.9,1.8,3
5.7,3.8,1.7,0.3,1
6,3.4,4.5,1.6,2
7.2,3,5.8,1.6,3
5.4,3.4,1.5,0.4,1
6.1,3,4.6,1.4,2
6.9,3.2,5.7,2.3,3
5,3.3,1.4,0.2,1
5.2,3.4,1.4,0.2,1
6.2,2.9,4.3,1.3,2
6.3,2.9,5.6,1.8,3
6.4,3.2,5.3,2.3,3
5.1,3.8,1.5,0.3,1
6.1,2.8,4.7,1.2,2
5.7,2.9,4.2,1.3,2
6,2.2,5,1.5,3
5.1,3.8,1.9,0.4,1
5.5,4.2,1.4,0.2,1
5.7,2.8,4.5,1.3,2
6.4,2.8,5.6,2.1,3
6.3,2.5,4.9,1.5,2
6,3,4.8,1.8,3
5.3,3.7,1.5,0.2,1
6.2,2.2,4.5,1.5,2
4.8,3,1.4,0.3,1
6.3,2.7,4.9,1.8,3
4.9,2.5,4.5,1.7,3
5.1,3.4,1.5,0.2,1
5.5,2.4,3.7,1,2
4.4,3.2,1.3,0.2,1
5.7,2.6,3.5,1,2
7.7,2.6,6.9,2.3,3
4.8,3,1.4,0.1,1
6.7,3,5.2,2.3,3
5.5,2.5,4,1.3,2
6.3,2.8,5.1,1.5,3
4.7,3.2,1.6,0.2,1
5.7,2.8,4.1,1.3,2
4.6,3.6,1,0.2,1
7.6,3,6.6,2.1,3
5.5,2.6,4.4,1.2,2
5.5,3.5,1.3,0.2,1
6.4,3.1,5.5,1.8,3
5.4,3,4.5,1.5,2";
}

public class DelegateWrapper
{
    public DelegateWrapper(Func<List<double>, List<double>, double> metric, string comboBoxLabel)
    {
        Metric = metric;
        ComboBoxLabel = comboBoxLabel;
    }

    public Func<List<double>, List<double>, double> Metric;
    public string ComboBoxLabel { get; set; }
}